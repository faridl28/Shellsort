package expo;

public class ShellSort {

    // Método principal para ordenar la lista usando Shellsort
    public static void shellSort(int[] arr) {
        int n = arr.length;

        // Comenzar con un gap grande, luego reducir el gap
        for (int gap = n / 2; gap > 0; gap /= 2) {
            // Realizar un ordenamiento por inserción para este gap tamaño
            for (int i = gap; i < n; i++) {
                int temp = arr[i];
                int j;

                // Cambiar elementos gap separados
                for (j = i; j >= gap && arr[j - gap] > temp; j -= gap) {
                    arr[j] = arr[j - gap];
                }

                // Colocar temp (el elemento original arr[i]) en su ubicación correcta
                arr[j] = temp;
            }
        }
    }

    // Método principal para ejecutar el programa
    public static void main(String[] args) {
        int[] arr = {9, 8, 7, 322, 215, 3, 10, 4, 6};

        System.out.println("Array original:");
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();

        // Llamar al método shellSort para ordenar el array
        shellSort(arr);

        System.out.println("Array ordenado:");
        for (int num : arr) {
            System.out.print(num + " ");
        }
    }

}
